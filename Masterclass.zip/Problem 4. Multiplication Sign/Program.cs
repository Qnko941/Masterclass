﻿using System;

namespace Problem_4._Multiplication_Sign
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("????!");
        }
    }
}
